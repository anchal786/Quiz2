const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const cors = require('cors'); 

const index = express();

// Middleware
index.use(cors()); 
index.use(express.urlencoded({ extended: true }));
index.use(express.json());
index.use(express.static(path.join(__dirname, 'public')));

// MongoDB URI route
index.post('/connect', async (req, res) => {
  try {
    const { myuri } = req.body;
    if (!myuri) {
      return res.status(400).json({ error: 'MongoDB URI is required' });
    }

    // Connect to MongoDB
    await mongoose.connect(myuri, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');

    // Define schema
    const studentSchema = new mongoose.Schema({
      name: String,
      studentID: String
    });

    // Create model
    const Student = mongoose.model('Student', studentSchema);

    // Create document
    const student = new Student({
      name: 'Anchal Anchal', 
      studentID: '300364004' 
    });

    // Save document to database
    await student.save();
    console.log('Document added to collection');

    res.send('<h1>Document Added</h1>');
  } catch (error) {
    console.error(error.message);
    res.status(500).send('Server Error');
  }
});

// Handle GET requests to the root URL
index.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'form.html'));
});

const PORT = process.env.PORT || 3000;

index.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
